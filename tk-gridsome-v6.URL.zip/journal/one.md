---
title: Electronics concepts
thumbnail: "/uploads/learn/01-SOC-Creative-Engineer-What-will-I-Learn-Icon-01-.png"
displayorder: 1
bgcolor: 'default'
textcolor: 'white'
---
You use all kinds of electronics devices all day—find out more about how they work! You’ll learn about digital vs. analog, input vs. output, and much more.
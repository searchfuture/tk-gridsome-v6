---
title: Code the micro:bit
thumbnail: "/uploads/learn/06-SOC-Digtial-Maker-What-will-I-Learn-Icon-02.png"
displayorder: 2
bgcolor: 'default'
textcolor: 'white'
---
The micro:bit is a tiny computer you can control with code. You’ll write your very own programs to control the micro:bit and various attached components!
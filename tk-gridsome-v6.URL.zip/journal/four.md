---
title: Computer Science concepts
thumbnail: "/uploads/learn/08-SOC-Digtial-Maker-What-will-I-Learn-Icon-04.png"
displayorder: 4
bgcolor: 'pink'
textcolor: 'black'
---
You may not hear us explicitly teaching these, but you’ll learn about core CS concepts like variables, event handlers, conditionals, and loops.
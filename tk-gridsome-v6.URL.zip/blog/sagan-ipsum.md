---
title: Sagan ipsum
excerpt: Hydrogen atoms colonies bits of moving fluff cosmic fugue gathered by gravity shores of the cosmic ocean.
date: 2019-04-21 17:00:00 +0000
author: Loke Carlsson
image: "/uploads/space.svg"
footer: false
---
*ตัวเอียง*
Billions upon billions Tunguska event galaxies rich in mystery decipherment billions upon billions. Bits of moving fluff rings of Uranus made in the interiors of collapsing stars from which we spring bits of moving fluff star stuff harvesting star light. The ash of stellar alchemy a mote of dust suspended in a sunbeam kindling the energy hidden in matter take root and flourish star stuff harvesting star light are creatures of the cosmos.

Tesseract something incredible is waiting to be known Cambrian explosion Flatland Jean-François Champollion rich in heavy atoms? At the edge of forever the ash of stellar alchemy shores of the cosmic ocean vastness is bearable only through love trillion white dwarf. Made in the interiors of collapsing stars finite but unbounded with pretty stories for which there's little good evidence gathered by gravity hearts of the stars a very small stage in a vast cosmic arena.

Rogue intelligent beings dream of the mind's eye vanquish the impossible white dwarf kindling the energy hidden in matter. The only home we've ever known two ghostly white figures in coveralls and helmets are soflty dancing a mote of dust suspended in a sunbeam bits of moving fluff not a sunrise but a galaxyrise made in the interiors of collapsing stars. Take root and flourish citizens of distant epochs rich in heavy atoms permanence of the stars dispassionate extraterrestrial observer inconspicuous motes of rock and gas and billions upon billions upon billions upon billions upon billions upon billions upon billions.
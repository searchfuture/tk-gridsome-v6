export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Thinkable Kids",
  "siteUrl": "https://searchfuture.github.io",
  "version": "0.7.12"
}
import plugin_gridsome_plugin_google_analytics_10 from "C:\\Users\\Administrator\\Desktop\\tk-gridsome-v6\\node_modules\\@gridsome\\plugin-google-analytics\\gridsome.client.js"

export default [
  {
    run: plugin_gridsome_plugin_google_analytics_10,
    options: {"id":"UA-72659574-10"}
  }
]

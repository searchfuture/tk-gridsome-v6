<template>
  <Layout>
    <div class="about-page" >
      <h1 class="mb-4">About</h1>
      <img class="about-image" src="../../uploads/profile.svg" />

      <p>Lorem ipsum dolor sit amet consectetur adipiscing elit, platea elementum mus lectus molestie et. Conubia taciti nunc proin vehicula et nascetur lacinia commodo non, penatibus vel dui pharetra inceptos himenaeos orci viverra ad, quis ullamcorper sit scelerisque nibh praesent imperdiet vulputate.</p>

      <p>Eros morbi himenaeos eget sagittis parturient, netus sapien pharetra semper iaculis orci, elementum ullamcorper eleifend aenean. Orci ligula euismod taciti conubia facilisis mattis laoreet, cras aliquam ultrices purus augue morbi, a litora feugiat dapibus per lacinia. </p>

      <p>Conubia non mi vulputate natoque nullam sem nascetur fames felis, hendrerit imperdiet pretium urna a augue nec quis lorem, orci sed vehicula pulvinar viverra nam lacus porttitor. Praesent id elementum aliquet dolor himenaeos primis urna vestibulum, molestie sagittis cursus facilisi tellus phasellus lacinia, viverra porttitor tincidunt tortor habitasse class luctus. </p>
    </div>
  </Layout>
</template>

<script>
export default {
  metaInfo: {
    title: 'About'
  }
}
</script>

<style lang="scss" scoped>
.about-page {
  margin: 1rem;
  color: white;
}

.about-image {
  display: block;
  margin: auto;
  width: 90%;
  max-width: 500px;
  padding-bottom: 50px;
}
</style>

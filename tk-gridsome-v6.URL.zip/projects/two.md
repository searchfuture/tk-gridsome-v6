---
date: 2019-05-16
year: 2019
title: Banana
category: Identity
thumbnail: "/uploads/features/microbit-plugged-in.gif"
categories:
- photography
- pink
project_bg_color: ''
project_fg_color: ''

---
They’re tiny handheld programmable computers jam-packed with tons of built-in features, like 25 red LED lights to flash messages and two programmable buttons to play your favourite games or skip songs. From using it as an automatic fish-feeder to playing a banana keyboard, the micro:bit has endless possibilities for you to start your Digital Maker journey!
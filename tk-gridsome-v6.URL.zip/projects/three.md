---
thumbnail: "/uploads/features/gameboy.jpg"
title: Porta400
date: 2019-01-03
categories:
- photography
- yellow
project_bg_color: ''
project_fg_color: ''
---

By the end of the course, you will better understand electronics concepts through handling the micro:bit independently, or with external sensors and actuators. You will also learn to use Microsoft’s Programming Experience Toolkit (PXT) programming environment and develop computational thinking skills. Then, showcase your creativity and innovation in an exciting team project to consolidate your learning. Find out more details about the curriculum.
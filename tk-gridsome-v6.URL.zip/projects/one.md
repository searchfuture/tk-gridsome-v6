---
thumbnail: "/uploads/features/02-microCamp-Course-Overview.jpg"
title: Camp Overview
date: 2019-07-02
categories:
- photography
- yellow
project_bg_color: ''
project_fg_color: "#FDC70D"
---
1Learn to prototype with the micro:bit microcontroller while creating fun projects in our 2-day microCamp! You’ll become familiar with programming concepts and electronics components, while building practical, hands-on electronics projects using the micro:bit.
At the end of the camp, you will create a simple game and a kit that looks like a handheld gameboy that you can take home. Furthermore, you’ll be well-equipped and hopefully inspired to make many more projects on the micro:bit.
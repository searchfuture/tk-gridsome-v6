---
title: Electronics concepts
thumbnail: "/uploads/cover/picture1.jpg"
displayorder: 1
bgcolor: 'default'
textcolor: 'white'
---
You use all kinds of electronics devices all day—find out more about how they work! You’ll learn about digital vs. analog, input vs. output, and much more.
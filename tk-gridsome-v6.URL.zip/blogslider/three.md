---
title: Program in MakeCode
thumbnail: "/uploads/cover/picture3.jpg"
displayorder: 3
bgcolor: 'default'
textcolor: 'white'
---
You’ll be doing your coding in Microsoft MakeCode, a beginner-friendly block-based programming environment. No semicolons or curly braces here!
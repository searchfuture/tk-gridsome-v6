---
title: Computer Science concepts
thumbnail: "/uploads/cover/picture4.jpg"
displayorder: 4
bgcolor: 'pink'
textcolor: 'black'
---
You may not hear us explicitly teaching these, but you’ll learn about core CS concepts like variables, event handlers, conditionals, and loops.
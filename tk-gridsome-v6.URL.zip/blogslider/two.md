---
title: Code the micro:bit
thumbnail: "/uploads/cover/picture2.jpg"
displayorder: 2
bgcolor: 'default'
textcolor: 'white'
---
The micro:bit is a tiny computer you can control with code. You’ll write your very own programs to control the micro:bit and various attached components!
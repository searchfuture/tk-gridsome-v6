---
title: Coming events
thumbnail: "/uploads/app.svg"
displayorder: 3
bgcolor: 'default'
textcolor: 'yellow'
---
We post—very occasionally—about upcoming workshops, public events, sales, and other news.

Email: hello@tinkercademy.com
Phone: 6917 6920
Love filling in forms: Contact form

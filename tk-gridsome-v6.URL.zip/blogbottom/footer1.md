---
title: About ThinkableKids
thumbnail: "/uploads/coffee.svg"
displayorder: 1
bgcolor: 'default'
textcolor: 'white'
---
About Tinkercademy
We’re coders and tinkerers who teach coding and tinkering to schools, corporations, and the public in Singapore. We bring an unparalleled depth of experience in education and technology to our classes and curriculum.
Even more about Tinkercademy
About us, and who we’ve worked with
Our people
Our Medium blog is a Build Log of what we’ve made
Tinkercademy is the education branding of Tinkertanker Pte Ltd

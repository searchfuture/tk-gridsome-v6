---
title: Get in touch!
thumbnail: "/uploads/space.svg"
displayorder: 2
bgcolor: ''
textcolor: ''
---
Get in touch!
We're at 201 Henderson Road #06-19, Apex @ Henderson, Singapore 159545. That's an industrial building in Henderson, where we 3D-print, laser-cut, and solder whatever we can see. Join us as a member to learn, code, and make together!


Email: hello@tinkercademy.com
Phone: 6917 6920
Love filling in forms: Contact form
